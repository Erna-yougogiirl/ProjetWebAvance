import { InscriptionDisabledDirectiveDirective } from './inscription-disabled-directive.directive';

describe('InscriptionDisabledDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new InscriptionDisabledDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
