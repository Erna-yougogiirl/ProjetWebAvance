export class participant {
    constructor(
    public nom: string,
    public prenom: string,
    public adresse: string,
    public email: string,
    public poste: string
    ) { }
    }