import { participant } from './participant';
export const PARTICIPANTS: participant[] = [
    {
        nom: 'mohammed',
        prenom: 'salah',
        adresse: 'rue',
        email: 'msalah@gmail.com',
        poste: 'joueur',
        },
    {
         nom: 'mimouni',
         prenom: 'anis',
         adresse: 'manouba',
         email: 'amimouni@gmail.com',
         poste: 'etudiant',
        
        }
        ];