export class formateur {
    constructor(
    public nom: string,
    public prenom: string,
    public adresse: string,
    public email: string,
    public domaine: string) { }
    }