export enum SidenavDirection {
    left = 'left',
    right = 'right'
}