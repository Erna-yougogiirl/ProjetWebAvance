import {formateur} from './formateur';
export const FORMATEURS: formateur[] = [
    {
        nom: 'Chebbi',
        prenom: 'rim',
        adresse: 'rue hussine dey',
        email: 'rchebbi94@gmail.com',
        domaine: 'angular',
        },
    {
         nom: 'Mettichi',
         prenom: 'amani',
         adresse: 'rue omar sghayer',
         email: 'amanim@gmail.com',
         domaine: 'Xamarin',
        
        }
        ];